Aqui se guardaran las imágenes descargadas (.jpg), tags (.tag) y archivos comprimidos (.tar)
