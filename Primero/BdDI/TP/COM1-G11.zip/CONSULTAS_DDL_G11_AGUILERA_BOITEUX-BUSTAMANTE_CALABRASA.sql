-- 4A

SELECT TOP 1 c.id_cuadrilla, COUNT(t.id_tarea) AS CANTIDAD_DE_TAREAS
FROM CUADRILLAS c
JOIN TAREAS t ON t.id_cuadrilla = c.id_cuadrilla
WHERE t.fecha_realizacion BETWEEN '2025-10-01' AND '2025-10-31'
GROUP BY c.id_cuadrilla
ORDER BY CANTIDAD_DE_TAREAS DESC


--4B

SELECT R.motivo, COUNT(*) AS CANTIDAD_MOTIVOS
FROM RECLAMOS R
WHERE R.id_tarea IS NULL
GROUP BY R.motivo
HAVING COUNT(*) > 3

--4C

SELECT a.id_arbol, E.nombre_comun, U.*
FROM ARBOLES a
LEFT JOIN RECLAMOS r ON a.id_arbol = r.id_arbol
JOIN ESPECIES E ON A.id_especie = E.id_especie
JOIN UBICACIONES U ON U.id_ubicacion = A.id_ubicacion
WHERE r.id_arbol IS NULL

--4D

SELECT t.id_especie, t.nombre_cientifico, t.altura
FROM (
	SELECT e.id_especie, e.nombre_cientifico, a.altura,
	ROW_NUMBER() OVER(PARTITION BY a.id_especie ORDER BY a.altura DESC) AS ranking
	FROM ARBOLES a
	JOIN ESPECIES e ON a.id_especie = e.id_especie
	) AS t
WHERE t.ranking <= 3
ORDER BY t.nombre_cientifico

-- 5A

SELECT * FROM vista5a
WHERE id_arbol = 1

SELECT * FROM vista5a
WHERE motivo = '�rbol inclinado'

-- 5B

SELECT * FROM vista5b
WHERE Tipo_Tarea = 'Fumigaci�n'

SELECT * From vista5b
WHERE Cantidad_Tareas > 3

-- 6

-- ejemplo de uso 1

DECLARE @FechaProxTarea DATE;
DECLARE @TotalPendientes INT;

EXEC @TotalPendientes = TAREAS_PENDIENTES
    @ARBOL = 3,
    @TIPO_TAREA = 4,
    @FECHA_RESULTADO = @FechaProxTarea OUTPUT;

SELECT
    @TotalPendientes AS [Cantidad de Tareas Pendientes],
    @FechaProxTarea AS [Pr�xima Fecha de Asignaci�n];

-- ejemplo de uso 2

DECLARE @FechaProxTarea2 DATE;
DECLARE @TotalPendientes2 INT;

EXEC @TotalPendientes2 = TAREAS_PENDIENTES
    @ARBOL = 1,
    @TIPO_TAREA = 1,
    @FECHA_RESULTADO = @FechaProxTarea2 OUTPUT;

SELECT
    @TotalPendientes2 AS [Cantidad de Tareas Pendientes],
    @FechaProxTarea2 AS [Pr�xima Fecha de Asignaci�n];