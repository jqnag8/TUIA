create database tp
use tp

create table ESPECIES (
	id_especie int identity primary key,
	nombre_comun varchar(100),
	nombre_cientifico varchar(100)
)

create table SALUD (
	id_salud int identity primary key,
	tipo varchar(50)
)

create table UBICACIONES (
	id_ubicacion int identity primary key,
	calle varchar(50) null,
	altura varchar(10) null,
	parque varchar(100) null,
	plaza varchar(100) null,
	coordenadas varchar(50)
)

create table ARBOLES (
	id_arbol int identity primary key,
	id_especie int,
	id_ubicacion int,
	id_salud int,
	fecha_plantacion date null,
	altura decimal(5,2) null,
	fecha_medicion date null,
	FOREIGN KEY (id_especie) REFERENCES ESPECIES(id_especie),
	FOREIGN KEY (id_ubicacion) REFERENCES UBICACIONES(id_ubicacion),
	FOREIGN KEY (id_salud) REFERENCES SALUD(id_salud)
)

create table CUADRILLAS (
	id_cuadrilla int identity primary key,
	codigo varchar(20) UNIQUE, -- UK
)

create table TIPOS_TAREAS (
	id_tipo_tarea int identity primary key,
	descripcion varchar(30)
)

create table TAREAS (
	id_tarea int identity primary key,
	id_tipo_tarea int,
	id_cuadrilla int,
	fecha_estimada date,
	fecha_realizacion date null,
	comentario varchar(255) null,
	FOREIGN KEY (id_tipo_tarea) REFERENCES TIPOS_TAREAS(id_tipo_tarea),
	FOREIGN KEY (id_cuadrilla) REFERENCES CUADRILLAS(id_cuadrilla)
)

create table RECLAMOS (
	id_reclamo int identity primary key,
	id_tarea int,
	id_arbol int,
	motivo varchar(255),
	fecha_reclamo date,
	fecha_asignacion date, --fecha de asignacion de una tarea
	email varchar(100),
	FOREIGN KEY (id_tarea) REFERENCES TAREAS(id_tarea),
	FOREIGN KEY (id_arbol) REFERENCES ARBOLES(id_arbol)
)

create table ARBOLES_TAREAS (
	id_arbol_tarea int identity primary key,
	id_arbol int,
	id_tarea int,
	FOREIGN KEY (id_tarea) REFERENCES TAREAS(id_tarea),
	FOREIGN KEY (id_arbol) REFERENCES ARBOLES(id_arbol)
)

create table EMPLEADOS (
	id_empleado int identity primary key,
	id_cuadrilla int,
	nombre varchar(50),
	apellido varchar(50),
	CUIL varchar(30) UNIQUE, -- UK
	telefono varchar(30),
	fecha_ingreso date,
	FOREIGN KEY (id_cuadrilla) REFERENCES CUADRILLAS(id_cuadrilla),
)
GO
-- 5a

CREATE VIEW vista5a AS
SELECT
	r.id_reclamo,
	r.fecha_reclamo,
	r.motivo, r.id_arbol,
	-- 1. C�lculo de d�as para ASIGNAR
    -- Si r.fecha_asignacion es NULL, usa GETDATE() (hoy). Luego calcula la diferencia.
    DATEDIFF(day, r.fecha_reclamo, ISNULL(r.fecha_asignacion, GETDATE())) AS dias_demora_asignacion,
    -- 2. C�lculo de d�as para RESOLVER
    -- Si t.fecha_realizacion es NULL, usa GETDATE() (hoy). Luego calcula la diferencia.
    DATEDIFF(day, r.fecha_reclamo, ISNULL(t.fecha_realizacion, GETDATE())) AS dias_demora_resolucion
FROM RECLAMOS r
LEFT JOIN TAREAS t ON r.id_tarea = t.id_tarea;
GO
-- 5b

CREATE VIEW vista5b AS
SELECT 
    tt.descripcion AS Tipo_Tarea,
    MIN(t.fecha_realizacion) AS Primera_Tarea,
    MAX(t.fecha_realizacion) AS Ultima_Tarea,
	COUNT(t.id_tarea) AS Cantidad_Tareas
FROM TAREAS t
JOIN TIPOS_TAREAS tt ON t.id_tipo_tarea = tt.id_tipo_tarea
WHERE t.fecha_realizacion IS NOT NULL
GROUP BY tt.descripcion;
GO
--6

CREATE PROCEDURE TAREAS_PENDIENTES
	@ARBOL int,
	@TIPO_TAREA int,
	@FECHA_RESULTADO date output
AS
	DECLARE @CANTIDAD_PENDIENTES int;
	SELECT @FECHA_RESULTADO = min(t.fecha_estimada), @CANTIDAD_PENDIENTES = COUNT(t.id_tarea)
	FROM TAREAS t
	JOIN ARBOLES_TAREAS art on art.id_tarea = t.id_tarea
	WHERE t.fecha_realizacion IS NULL 
		AND t.id_tipo_tarea = @TIPO_TAREA 
		AND art.id_arbol = @ARBOL
	RETURN @CANTIDAD_PENDIENTES;
GO