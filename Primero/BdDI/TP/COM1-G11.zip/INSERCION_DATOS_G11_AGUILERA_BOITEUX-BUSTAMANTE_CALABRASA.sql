-- Especies (5 especies)
INSERT INTO ESPECIES (nombre_comun, nombre_cientifico) VALUES 
('Jacarand�', 'Jacaranda mimosifolia'),
('Ceibo', 'Erythrina crista-galli'),
('Lapacho Rosado', 'Handroanthus impetiginosus'),
('Palo Borracho', 'Ceiba speciosa'),
('Tipa', 'Tipuana tipu');

-- Salud (5 estados)
INSERT INTO SALUD (tipo) VALUES 
('Sano'), 
('D�bil'), 
('Seco'), 
('Enfermo/Peste'),
('Riesgo de Ca�da');

-- Ubicaciones (10 ubicaciones)
INSERT INTO UBICACIONES (calle, altura, parque, plaza, coordenadas) VALUES 
('Av. Pellegrini', '1500', NULL, NULL, '-32.95, -60.65'),
('Bv. Oro�o', '800', NULL, NULL, '-32.94, -60.65'),
('C�rdoba', '2300', NULL, NULL, '-32.94, -60.66'),
(NULL, NULL, 'Parque Independencia', NULL, '-32.96, -60.66'),
(NULL, NULL, 'Parque Espa�a', NULL, '-32.93, -60.63'),
(NULL, NULL, NULL, 'Plaza San Mart�n', '-32.94, -60.64'),
('San Luis', '1200', NULL, NULL, '-32.95, -60.64'),
('Rioja', '500', NULL, NULL, '-32.95, -60.63'),
(NULL, NULL, 'Parque Urquiza', NULL, '-32.96, -60.62'),
(NULL, NULL, NULL, 'Plaza 25 de Mayo', '-32.94, -60.63');

-- Tipos de Tareas (5 tipos)
INSERT INTO TIPOS_TAREAS (descripcion) VALUES 
('Poda Correctiva'), 
('Extracci�n'), 
('Plantaci�n'), 
('Fumigaci�n'), 
('Riego');

-- Cuadrillas (3 cuadrillas)
INSERT INTO CUADRILLAS (codigo) VALUES 
('A'), 
('B'), 
('C');

-- Empleados (10 empleados)
INSERT INTO EMPLEADOS (id_cuadrilla, nombre, apellido, CUIL, telefono, fecha_ingreso) VALUES
(1, 'Juan', 'P�rez', '20-11111111-1', '341-111111', '2020-03-15'),
(1, 'Mar�a', 'G�mez', '27-22222222-2', '341-222222', '2021-05-20'),
(1, 'Carlos', 'L�pez', '20-33333333-3', '341-333333', '2019-08-10'),
(2, 'Ana', 'D�az', '27-44444444-4', '341-444444', '2022-01-05'),
(2, 'Pedro', 'Ruiz', '20-55555555-5', '341-555555', '2022-02-15'),
(2, 'Laura', 'Mendez', '27-66666666-6', '341-666666', '2023-06-30'),
(2, 'Jorge', 'Fernandez', '20-77777777-7', '341-777777', '2020-11-22'),
(3, 'Sof�a', 'Torres', '27-88888888-8', '341-888888', '2018-04-12'),
(3, 'Miguel', 'Bravo', '20-99999999-9', '341-999999', '2021-09-09'),
(3, 'Luc�a', 'Cano', '27-10101010-1', '341-000000', '2023-03-03');

-- Arboles (50 arboles)
INSERT INTO ARBOLES (id_especie, id_ubicacion, id_salud, fecha_plantacion, altura, fecha_medicion) VALUES
-- Datos completos
(1, 1, 1, '2010-05-15', 5.50, '2024-01-10'),
(2, 2, 1, '2012-08-20', 4.20, '2024-02-15'),
(3, 3, 2, '2015-03-10', 3.80, '2024-03-01'),
(4, 4, 1, '2008-11-05', 8.10, '2023-12-20'),
(5, 5, 1, '2018-09-25', 2.50, '2024-04-10'),
(1, 6, 3, '2005-06-30', 10.00, '2023-11-15'),
(2, 7, 1, '2019-04-15', 2.10, '2024-05-05'),
(3, 8, 4, '2011-07-22', 6.30, '2024-01-25'),
(4, 9, 1, '2014-02-14', 7.00, '2024-02-28'),
(5, 10, 5, '2009-10-10', 9.50, '2023-12-05'),
-- Sin fecha de plantaci�n
(1, 1, 1, NULL, 12.50, '2024-01-12'),
(2, 2, 2, NULL, 8.20, '2024-02-18'),
(3, 3, 1, NULL, 9.10, '2024-03-05'),
(4, 4, 1, NULL, 15.00, '2023-12-22'),
(5, 5, 3, NULL, 11.30, '2024-04-12'),
(1, 6, 1, NULL, 10.50, '2023-11-18'),
(2, 7, 1, NULL, 7.80, '2024-05-08'),
(3, 8, 1, NULL, 8.90, '2024-01-28'),
(4, 9, 2, NULL, 14.20, '2024-03-01'),
(5, 10, 1, NULL, 13.00, '2023-12-08'),
-- Sin altura ni medici�n
(1, 2, 1, '2023-08-15', NULL, NULL),
(2, 3, 1, '2023-09-20', NULL, NULL),
(3, 4, 1, '2024-03-10', NULL, NULL),
(4, 5, 4, '2023-05-05', NULL, NULL),
(5, 6, 1, '2023-11-25', NULL, NULL),
(1, 7, 1, '2024-01-15', NULL, NULL),
(2, 8, 1, '2024-02-20', NULL, NULL),
(3, 9, 2, '2023-07-10', NULL, NULL),
(4, 10, 1, '2023-12-01', NULL, NULL),
(5, 1, 1, '2024-04-05', NULL, NULL),
-- Aleatorio
(1, 3, 1, '2016-01-01', 4.5, '2024-01-01'),
(2, 4, 2, NULL, 6.0, '2024-01-01'),
(3, 5, 1, NULL, NULL, NULL),
(4, 6, 3, '2010-05-05', 8.0, '2023-12-01'),
(5, 7, 1, '2020-02-20', 1.8, '2024-05-01'),
(1, 8, 1, NULL, 11.0, '2024-01-01'),
(2, 9, 1, '2015-06-15', 5.2, '2024-02-01'),
(3, 10, 4, NULL, NULL, NULL),
(4, 1, 1, '2017-09-09', 3.9, '2024-03-01'),
(5, 2, 1, NULL, 9.8, '2024-04-01'),
(1, 4, 2, '2021-11-11', 2.2, '2024-05-01'),
(2, 5, 1, NULL, NULL, NULL),
(3, 6, 1, '2013-03-13', 6.5, '2023-12-15'),
(4, 7, 5, NULL, 14.0, '2024-01-10'),
(5, 8, 1, '2019-08-08', 2.9, '2024-02-10'),
(1, 9, 1, NULL, 10.2, '2024-03-10'),
(2, 10, 3, '2000-01-01', 16.0, '2023-11-01'),
(3, 1, 1, '2022-05-05', 1.5, '2024-04-15'),
(4, 2, 1, NULL, NULL, NULL),
(5, 3, 1, '2018-12-12', 4.0, '2024-05-15');

-- Tareas (20 Tareas)
INSERT INTO TAREAS (id_tipo_tarea, id_cuadrilla, fecha_estimada, fecha_realizacion, comentario) VALUES
-- SEPTIEMBRE 2025
(1, 1, '2025-09-05', '2025-09-06', 'Poda de ramas bajas'),
(1, 2, '2025-09-10', '2025-09-11', 'Poda de formaci�n'),
(2, 3, '2025-09-12', '2025-09-13', 'Extracci�n �rbol seco'),
(4, 1, '2025-09-15', NULL, 'Fumigaci�n preventiva'),
(3, 2, '2025-09-20', '2025-09-21', 'Plantaci�n nuevos ejemplares'),
(5, 3, '2025-09-25', '2025-09-25', 'Riego semanal'),
(1, 1, '2025-09-28', '2025-09-28', 'Despeje de luminarias'),
-- OCTUBRE 2025
(2, 2, '2025-10-02', '2025-10-02', 'Retiro �rbol ca�do tormenta'),
(4, 3, '2025-10-05', '2025-10-06', 'Tratamiento pulg�n'),
(5, 1, '2025-10-10', '2025-10-10', 'Riego de refuerzo'),
(1, 2, '2025-10-15', '2025-10-16', 'Poda correctiva'),
(3, 3, '2025-10-20', '2025-10-21', 'Reposici�n ejemplar'),
(2, 1, '2025-10-25', NULL, 'Extracci�n ra�z peligrosa'),
(4, 2, '2025-10-28', '2025-10-29', 'Fumigaci�n plaza completa'),
-- NOVIEMBRE 2025
(1, 3, '2025-11-01', '2025-11-02', 'Poda altura'),
(5, 1, '2025-11-05', '2025-11-05', 'Riego'),
(3, 2, '2025-11-10', '2025-11-11', 'Plantaci�n nativas'),
(1, 3, '2025-11-15', '2025-11-15', 'Corte de ramas peligrosas'),
(2, 1, '2025-11-20', '2025-11-21', 'Extracci�n'),
(4, 2, '2025-11-25', NULL, 'Control de plagas');

-- ARBOLES_TAREAS
INSERT INTO ARBOLES_TAREAS (id_tarea, id_arbol) VALUES
(1, 1),
(2, 2), 
(3, 6),
(4, 8), 
(4, 9),
(5, 21),
(6, 22), (6, 23), (6, 24),
(7, 5),
(8, 37),
(9, 12),
(10, 21),
(11, 30),
(12, 40),
(13, 45),
(14, 4), (14, 14), (14, 24),
(15, 11),
(16, 35),
(17, 48), (17, 49),
(18, 50),
(19, 47),
(20, 3);

-- Reclamos (20 Reclamos)
INSERT INTO RECLAMOS (id_tarea, id_arbol, motivo, fecha_reclamo, fecha_asignacion, email) VALUES
-- SEPTIEMBRE
(1, 1, 'Ramas tocan cables', '2025-09-02', '2025-09-05', 'vecino1@mail.com'),
(2, 2, '�rbol tapa sem�foro', '2025-09-08', '2025-09-10', 'transito@rosario.gov.ar'),
(3, 6, '�rbol totalmente seco', '2025-09-10', '2025-09-12', 'vecino2@mail.com'),
(4, 8, 'Tiene bichos', '2025-09-12', '2025-09-15', 'vecino3@mail.com'),
(4, 9, 'Mismo problema de bichos', '2025-09-12', '2025-09-15', 'vecino4@mail.com'),
-- OCTUBRE
(7, 5, 'Oscuridad por ramas', '2025-10-01', '2025-10-02', 'alumbrado@rosario.gov.ar'),
(8, 37, 'ARBOL CAIDO', '2025-10-02', '2025-10-02', 'emergencia@rosario.gov.ar'),
(8, 37, 'Se cay� un �rbol en la calle', '2025-10-02', '2025-10-02', 'vecino5@mail.com'),
(NULL, 40, 'Falta un �rbol aqu�', '2025-10-05', NULL, 'vecino6@mail.com'),
(NULL, 42, '�rbol inclinado', '2025-10-15', NULL, 'vecino7@mail.com'),
(NULL, 41, '�rbol inclinado', '2025-10-15', NULL, 'vecino7@mail.com'),
(NULL, 41, '�rbol inclinado', '2025-10-15', NULL, 'vecino7@mail.com'),
(NULL, 41, '�rbol inclinado', '2025-10-15', NULL, 'vecino8@mail.com'),
(13, 45, 'Levanta vereda', '2025-10-20', '2025-10-25', 'vecino9@mail.com'),
(14, 4, 'Muchos mosquitos en la plaza', '2025-10-26', '2025-10-28', 'vecino_plaza@mail.com'),
-- NOVIEMBRE
(NULL, 20, 'Ramas bajas', '2025-11-01', NULL, 'vecino10@mail.com'),
(18, 50, 'Rama por caerse', '2025-11-12', '2025-11-15', 'vecino11@mail.com'),
(19, 47, '�rbol muerto', '2025-11-18', '2025-11-20', 'admin_parque@mail.com'),
(NULL, 15, 'Poda por favor', '2025-11-26', NULL, 'juan@mail.com'),
(NULL, 16, 'Ra�ces rompen ca�o', '2025-11-26', NULL, 'aguas@servicios.com'),
(20, 3, 'Hojas con manchas', '2025-11-22', '2025-11-25', 'biologo@mail.com'),
(NULL, 33, 'Solicitud de plantaci�n', '2025-11-28', NULL, 'escuela@mail.com'),
(NULL, 34, '�rbol obstruye visi�n', '2025-11-28', NULL, 'seguridad@mail.com');